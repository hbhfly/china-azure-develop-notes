﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SpaceAdder
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string filePath = @"C:\SpaceAdder\file.txt";
            string spaceBefore = @"([\u4e00-\u9fff])([\u0030-\u0039|\u0041-\u005a|\u0061-\u007a])";   //add space before an English word
            string spaceAfter = @"([\u0030-\u0039|\u0041-\u005a|\u0061-\u007a])([\u4e00-\u9fff])";    //add space after an English word
            string[] line = System.IO.File.ReadAllLines(filePath);
            foreach (string s in line)
            {
                AddSpace(s, spaceBefore);
                AddSpace(s, spaceAfter);
            }
            //matchResult(filePath, spaceBefore);
            //matchResult(filePath, spaceAfter);
        }
        
        public static void AddSpace(string path, string pattern)
        {
            string content = System.IO.File.ReadAllText(path);
            Regex rgx1 = new Regex(pattern);
            content = Regex.Replace(content, pattern, "$1 $2", RegexOptions.IgnoreCase);
            System.IO.File.WriteAllText(path, content);
        }

        //Method for troubleshoot, show all match result
        public static void matchResult(string path, string pattern)
        {
            string content = System.IO.File.ReadAllText(path);

            var matchResult = Regex.Matches(content, pattern, RegexOptions.IgnoreCase);
            List<string> group0 = new List<string>();
            List<string> group1 = new List<string>();
            List<string> group2 = new List<string>();
            foreach (Match match in matchResult)
            {
                group0.Add(match.Groups[0].Value);
                group1.Add(match.Groups[1].Value);
                group2.Add(match.Groups[2].Value);
            }
            var max1 = group0.Max(s => s.Length) + 5;
            var max2 = group1.Max(s => s.Length) + 5;
            var max3 = group2.Max(s => s.Length) + 5;
            foreach (Match match in matchResult)
            {
                Console.WriteLine(String.Format("|group0: {0,-" + (max1- match.Groups[0].Value.Length) + "} | group1: {1,-" + (max2- match.Groups[1].Value.Length) + "} | group2: {2,-" + (max3- match.Groups[2].Value.Length) + "}|", match.Groups[0].Value, match.Groups[1].Value, match.Groups[2].Value));
            }
            Console.ReadLine();
        }
    }
}
